/**
 * Generated from platform:/resource/ca.mcgill.ecse.fairtracks.queries/src/ca/mcgill/ecse/fairtracks/queries/fairtracksQueries.vql
 */
package ca.mcgill.ecse.fairtracks.queries;

import ca.mcgill.ecse.fairtracks.queries.CountObjectWithDistance;
import ca.mcgill.ecse.fairtracks.queries.CountObstacle;
import ca.mcgill.ecse.fairtracks.queries.CountPlayer;
import ca.mcgill.ecse.fairtracks.queries.CountRealCoordinates;
import ca.mcgill.ecse.fairtracks.queries.CountStaticObject;
import ca.mcgill.ecse.fairtracks.queries.CountZipline;
import ca.mcgill.ecse.fairtracks.queries.CountZone;
import ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole;
import org.eclipse.viatra.query.runtime.api.ViatraQueryEngine;
import org.eclipse.viatra.query.runtime.api.impl.BaseGeneratedPatternGroup;

/**
 * A pattern group formed of all public patterns defined in fairtracksQueries.vql.
 * 
 * <p>Use the static instance as any {@link interface org.eclipse.viatra.query.runtime.api.IQueryGroup}, to conveniently prepare
 * a VIATRA Query engine for matching all patterns originally defined in file fairtracksQueries.vql,
 * in order to achieve better performance than one-by-one on-demand matcher initialization.
 * 
 * <p> From package ca.mcgill.ecse.fairtracks.queries, the group contains the definition of the following patterns: <ul>
 * <li>countStaticObject</li>
 * <li>countRealCoordinates</li>
 * <li>countObjectWithDistance</li>
 * <li>countPlayer</li>
 * <li>countZone</li>
 * <li>countObstacle</li>
 * <li>countZipline</li>
 * <li>PlayerDistinctRole</li>
 * </ul>
 * 
 * @see IQueryGroup
 * 
 */
@SuppressWarnings("all")
public final class FairtracksQueries extends BaseGeneratedPatternGroup {
  /**
   * Access the pattern group.
   * 
   * @return the singleton instance of the group
   * @throws ViatraQueryRuntimeException if there was an error loading the generated code of pattern specifications
   * 
   */
  public static FairtracksQueries instance() {
    if (INSTANCE == null) {
        INSTANCE = new FairtracksQueries();
    }
    return INSTANCE;
  }
  
  private static FairtracksQueries INSTANCE;
  
  private FairtracksQueries() {
    querySpecifications.add(CountStaticObject.instance());
    querySpecifications.add(CountRealCoordinates.instance());
    querySpecifications.add(CountObjectWithDistance.instance());
    querySpecifications.add(CountPlayer.instance());
    querySpecifications.add(CountZone.instance());
    querySpecifications.add(CountObstacle.instance());
    querySpecifications.add(CountZipline.instance());
    querySpecifications.add(PlayerDistinctRole.instance());
  }
  
  public CountStaticObject getCountStaticObject() {
    return CountStaticObject.instance();
  }
  
  public CountStaticObject.Matcher getCountStaticObject(final ViatraQueryEngine engine) {
    return CountStaticObject.Matcher.on(engine);
  }
  
  public CountRealCoordinates getCountRealCoordinates() {
    return CountRealCoordinates.instance();
  }
  
  public CountRealCoordinates.Matcher getCountRealCoordinates(final ViatraQueryEngine engine) {
    return CountRealCoordinates.Matcher.on(engine);
  }
  
  public CountObjectWithDistance getCountObjectWithDistance() {
    return CountObjectWithDistance.instance();
  }
  
  public CountObjectWithDistance.Matcher getCountObjectWithDistance(final ViatraQueryEngine engine) {
    return CountObjectWithDistance.Matcher.on(engine);
  }
  
  public CountPlayer getCountPlayer() {
    return CountPlayer.instance();
  }
  
  public CountPlayer.Matcher getCountPlayer(final ViatraQueryEngine engine) {
    return CountPlayer.Matcher.on(engine);
  }
  
  public CountZone getCountZone() {
    return CountZone.instance();
  }
  
  public CountZone.Matcher getCountZone(final ViatraQueryEngine engine) {
    return CountZone.Matcher.on(engine);
  }
  
  public CountObstacle getCountObstacle() {
    return CountObstacle.instance();
  }
  
  public CountObstacle.Matcher getCountObstacle(final ViatraQueryEngine engine) {
    return CountObstacle.Matcher.on(engine);
  }
  
  public CountZipline getCountZipline() {
    return CountZipline.instance();
  }
  
  public CountZipline.Matcher getCountZipline(final ViatraQueryEngine engine) {
    return CountZipline.Matcher.on(engine);
  }
  
  public PlayerDistinctRole getPlayerDistinctRole() {
    return PlayerDistinctRole.instance();
  }
  
  public PlayerDistinctRole.Matcher getPlayerDistinctRole(final ViatraQueryEngine engine) {
    return PlayerDistinctRole.Matcher.on(engine);
  }
}
