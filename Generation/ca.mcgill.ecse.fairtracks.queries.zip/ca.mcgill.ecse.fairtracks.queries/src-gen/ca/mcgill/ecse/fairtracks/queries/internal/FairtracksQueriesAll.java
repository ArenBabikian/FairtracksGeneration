/**
 * Generated from platform:/resource/ca.mcgill.ecse.fairtracks.queries/src/ca/mcgill/ecse/fairtracks/queries/fairtracksQueries.vql
 */
package ca.mcgill.ecse.fairtracks.queries.internal;

import ca.mcgill.ecse.fairtracks.queries.CountObjectWithDistance;
import ca.mcgill.ecse.fairtracks.queries.CountObstacle;
import ca.mcgill.ecse.fairtracks.queries.CountPlayer;
import ca.mcgill.ecse.fairtracks.queries.CountRealCoordinates;
import ca.mcgill.ecse.fairtracks.queries.CountStaticObject;
import ca.mcgill.ecse.fairtracks.queries.CountZipline;
import ca.mcgill.ecse.fairtracks.queries.CountZone;
import ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole;
import ca.mcgill.ecse.fairtracks.queries.internal.HelperFTObstacle;
import ca.mcgill.ecse.fairtracks.queries.internal.HelperFTPlayer;
import ca.mcgill.ecse.fairtracks.queries.internal.HelperFTZipline;
import ca.mcgill.ecse.fairtracks.queries.internal.HelperFTZone;
import org.eclipse.viatra.query.runtime.api.impl.BaseGeneratedPatternGroup;

/**
 * A pattern group formed of all patterns defined in fairtracksQueries.vql.
 * 
 * <p>A private group that includes private patterns as well. Only intended use case is for pattern testing.
 * 
 * <p> From package ca.mcgill.ecse.fairtracks.queries, the group contains the definition of the following patterns: <ul>
 * <li>helperFTPlayer</li>
 * <li>helperFTZone</li>
 * <li>helperFTObstacle</li>
 * <li>helperFTZipline</li>
 * <li>countStaticObject</li>
 * <li>countRealCoordinates</li>
 * <li>countObjectWithDistance</li>
 * <li>countPlayer</li>
 * <li>countZone</li>
 * <li>countObstacle</li>
 * <li>countZipline</li>
 * <li>PlayerDistinctRole</li>
 * </ul>
 * 
 * @see IQueryGroup
 * 
 */
@SuppressWarnings("all")
public final class FairtracksQueriesAll extends BaseGeneratedPatternGroup {
  /**
   * Access the pattern group.
   * 
   * @return the singleton instance of the group
   * @throws ViatraQueryRuntimeException if there was an error loading the generated code of pattern specifications
   * 
   */
  public static FairtracksQueriesAll instance() {
    if (INSTANCE == null) {
        INSTANCE = new FairtracksQueriesAll();
    }
    return INSTANCE;
  }
  
  private static FairtracksQueriesAll INSTANCE;
  
  private FairtracksQueriesAll() {
    querySpecifications.add(HelperFTPlayer.instance());
    querySpecifications.add(HelperFTZone.instance());
    querySpecifications.add(HelperFTObstacle.instance());
    querySpecifications.add(HelperFTZipline.instance());
    querySpecifications.add(CountStaticObject.instance());
    querySpecifications.add(CountRealCoordinates.instance());
    querySpecifications.add(CountObjectWithDistance.instance());
    querySpecifications.add(CountPlayer.instance());
    querySpecifications.add(CountZone.instance());
    querySpecifications.add(CountObstacle.instance());
    querySpecifications.add(CountZipline.instance());
    querySpecifications.add(PlayerDistinctRole.instance());
  }
}
