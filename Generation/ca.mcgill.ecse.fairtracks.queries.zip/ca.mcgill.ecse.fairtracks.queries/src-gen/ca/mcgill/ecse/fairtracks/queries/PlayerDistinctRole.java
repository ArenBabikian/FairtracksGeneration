/**
 * Generated from platform:/resource/ca.mcgill.ecse.fairtracks.queries/src/ca/mcgill/ecse/fairtracks/queries/fairtracksQueries.vql
 */
package ca.mcgill.ecse.fairtracks.queries;

import ca.mcgill.ecse.fairtracks.fairtracksDsl.FTPlayer;
import ca.mcgill.ecse.fairtracks.fairtracksDsl.FTRole;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.viatra.query.runtime.api.IPatternMatch;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.viatra.query.runtime.api.ViatraQueryEngine;
import org.eclipse.viatra.query.runtime.api.impl.BaseGeneratedEMFPQuery;
import org.eclipse.viatra.query.runtime.api.impl.BaseGeneratedEMFQuerySpecification;
import org.eclipse.viatra.query.runtime.api.impl.BaseMatcher;
import org.eclipse.viatra.query.runtime.api.impl.BasePatternMatch;
import org.eclipse.viatra.query.runtime.emf.types.EClassTransitiveInstancesKey;
import org.eclipse.viatra.query.runtime.emf.types.EDataTypeInSlotsKey;
import org.eclipse.viatra.query.runtime.emf.types.EStructuralFeatureInstancesKey;
import org.eclipse.viatra.query.runtime.matchers.backend.QueryEvaluationHint;
import org.eclipse.viatra.query.runtime.matchers.psystem.PBody;
import org.eclipse.viatra.query.runtime.matchers.psystem.PVariable;
import org.eclipse.viatra.query.runtime.matchers.psystem.annotations.PAnnotation;
import org.eclipse.viatra.query.runtime.matchers.psystem.annotations.ParameterReference;
import org.eclipse.viatra.query.runtime.matchers.psystem.basicdeferred.Equality;
import org.eclipse.viatra.query.runtime.matchers.psystem.basicdeferred.ExportedParameter;
import org.eclipse.viatra.query.runtime.matchers.psystem.basicdeferred.Inequality;
import org.eclipse.viatra.query.runtime.matchers.psystem.basicenumerables.TypeConstraint;
import org.eclipse.viatra.query.runtime.matchers.psystem.queries.PParameter;
import org.eclipse.viatra.query.runtime.matchers.psystem.queries.PParameterDirection;
import org.eclipse.viatra.query.runtime.matchers.psystem.queries.PVisibility;
import org.eclipse.viatra.query.runtime.matchers.tuple.Tuple;
import org.eclipse.viatra.query.runtime.matchers.tuple.Tuples;
import org.eclipse.viatra.query.runtime.util.ViatraQueryLoggingUtil;

/**
 * A pattern-specific query specification that can instantiate Matcher in a type-safe way.
 * 
 * <p>Original source:
 *         <code><pre>
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "Distance count", key = {o1})
 *         //pattern countDistance(o1 : FTDistance){
 *         //	FTDistance(o1);
 *         //}
 *         
 *         
 *         //3. Dynamic Classes
 *         /
 *         
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "Trajectory count", key = {o1})
 *         //pattern countTrajectory(o1 : FTTrajectory){
 *         //	FTTrajectory(o1);
 *         //}
 *         //
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "State count", key = {o1})
 *         //pattern countState(o1 : FTState){
 *         //	FTState(o1);
 *         //}
 *         //
 *         //
 *         //private pattern helperFTDistanceObs(o1 : FTDistanceObs){
 *         //	FTDistanceObs(o1);
 *         //}
 *         //
 *         //private pattern helperFTZoneObs(o1 : FTZoneObs){
 *         //	FTZoneObs(o1);
 *         //}
 *         //
 *         //private pattern helperFTPickupObs(o1 : FTPickUpObs){
 *         //	FTPickUpObs(o1);
 *         //}
 *         //
 *         //private pattern helperFTHangingObs(o1 : FTHangingObs){
 *         //	FTHangingObs(o1);
 *         //}
 *         //
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "Making Observations Abstract", key = {o1})
 *         //pattern countObservation(o1 : FTObservation){
 *         //	FTObservation(o1);
 *         //	neg find helperFTDistanceObs(o1);
 *         //	neg find helperFTZoneObs(o1);
 *         //	neg find helperFTPickupObs(o1);
 *         //	neg find helperFTHangingObs(o1);
 *         //}
 *         //
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "DistanceObs count", key = {o1})
 *         //pattern countDistanceObs(o1 : FTDistanceObs){
 *         //	FTDistanceObs(o1);
 *         //}
 *         //
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "ZoneObs count", key = {o1})
 *         //pattern countZoneObs(o1 : FTZoneObs){
 *         //	FTZoneObs(o1);
 *         //}
 *         //
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "PickUpObs count", key = {o1})
 *         //pattern countPickUpObs(o1 : FTPickUpObs){
 *         //	FTPickUpObs(o1);
 *         //}
 *         //
 *         //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "HangingObs count", key = {o1})
 *         //pattern countHangingsObs(o1 : FTHangingObs){
 *         //	FTHangingObs(o1);
 *         //}
 *         
 *         
 *         /
 *         //StaticObject Constraints
 *         /
 *         
 *         /
 *         //Player Constraints
 *         /
 *         
 *         //#1
 *         //keys are for symetry. will not give 2 errors for this
 *         {@literal @}Constraint(
 *         	targetEditorId = "ca.mcgill.ecse.FairtracksDsl", 
 *         	severity = "error", 
 *         	message = "Players have duplicate role", 
 *         	key = {p1, p2}
 *         )
 *         pattern PlayerDistinctRole(	
 *         	p1 : FTPlayer, 	p2 : FTPlayer, commonRole : FTRole
 *         ) {
 *         	FTPlayer.role(p1, commonRole);
 *         	FTPlayer.role(p2, commonRole);
 *         	p1 != p2;
 *         }
 * </pre></code>
 * 
 * @see Matcher
 * @see Match
 * 
 */
@SuppressWarnings("all")
public final class PlayerDistinctRole extends BaseGeneratedEMFQuerySpecification<PlayerDistinctRole.Matcher> {
  /**
   * Pattern-specific match representation of the ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole pattern,
   * to be used in conjunction with {@link Matcher}.
   * 
   * <p>Class fields correspond to parameters of the pattern. Fields with value null are considered unassigned.
   * Each instance is a (possibly partial) substitution of pattern parameters,
   * usable to represent a match of the pattern in the result of a query,
   * or to specify the bound (fixed) input parameters when issuing a query.
   * 
   * @see Matcher
   * 
   */
  public static abstract class Match extends BasePatternMatch {
    private FTPlayer fP1;
    
    private FTPlayer fP2;
    
    private FTRole fCommonRole;
    
    private static List<String> parameterNames = makeImmutableList("p1", "p2", "commonRole");
    
    private Match(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      this.fP1 = pP1;
      this.fP2 = pP2;
      this.fCommonRole = pCommonRole;
    }
    
    @Override
    public Object get(final String parameterName) {
      if ("p1".equals(parameterName)) return this.fP1;
      if ("p2".equals(parameterName)) return this.fP2;
      if ("commonRole".equals(parameterName)) return this.fCommonRole;
      return null;
    }
    
    public FTPlayer getP1() {
      return this.fP1;
    }
    
    public FTPlayer getP2() {
      return this.fP2;
    }
    
    public FTRole getCommonRole() {
      return this.fCommonRole;
    }
    
    @Override
    public boolean set(final String parameterName, final Object newValue) {
      if (!isMutable()) throw new java.lang.UnsupportedOperationException();
      if ("p1".equals(parameterName) ) {
          this.fP1 = (FTPlayer) newValue;
          return true;
      }
      if ("p2".equals(parameterName) ) {
          this.fP2 = (FTPlayer) newValue;
          return true;
      }
      if ("commonRole".equals(parameterName) ) {
          this.fCommonRole = (FTRole) newValue;
          return true;
      }
      return false;
    }
    
    public void setP1(final FTPlayer pP1) {
      if (!isMutable()) throw new java.lang.UnsupportedOperationException();
      this.fP1 = pP1;
    }
    
    public void setP2(final FTPlayer pP2) {
      if (!isMutable()) throw new java.lang.UnsupportedOperationException();
      this.fP2 = pP2;
    }
    
    public void setCommonRole(final FTRole pCommonRole) {
      if (!isMutable()) throw new java.lang.UnsupportedOperationException();
      this.fCommonRole = pCommonRole;
    }
    
    @Override
    public String patternName() {
      return "ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole";
    }
    
    @Override
    public List<String> parameterNames() {
      return PlayerDistinctRole.Match.parameterNames;
    }
    
    @Override
    public Object[] toArray() {
      return new Object[]{fP1, fP2, fCommonRole};
    }
    
    @Override
    public PlayerDistinctRole.Match toImmutable() {
      return isMutable() ? newMatch(fP1, fP2, fCommonRole) : this;
    }
    
    @Override
    public String prettyPrint() {
      StringBuilder result = new StringBuilder();
      result.append("\"p1\"=" + prettyPrintValue(fP1) + ", ");
      result.append("\"p2\"=" + prettyPrintValue(fP2) + ", ");
      result.append("\"commonRole\"=" + prettyPrintValue(fCommonRole));
      return result.toString();
    }
    
    @Override
    public int hashCode() {
      return Objects.hash(fP1, fP2, fCommonRole);
    }
    
    @Override
    public boolean equals(final Object obj) {
      if (this == obj)
          return true;
      if (obj == null) {
          return false;
      }
      if ((obj instanceof PlayerDistinctRole.Match)) {
          PlayerDistinctRole.Match other = (PlayerDistinctRole.Match) obj;
          return Objects.equals(fP1, other.fP1) && Objects.equals(fP2, other.fP2) && Objects.equals(fCommonRole, other.fCommonRole);
      } else {
          // this should be infrequent
          if (!(obj instanceof IPatternMatch)) {
              return false;
          }
          IPatternMatch otherSig  = (IPatternMatch) obj;
          return Objects.equals(specification(), otherSig.specification()) && Arrays.deepEquals(toArray(), otherSig.toArray());
      }
    }
    
    @Override
    public PlayerDistinctRole specification() {
      return PlayerDistinctRole.instance();
    }
    
    /**
     * Returns an empty, mutable match.
     * Fields of the mutable match can be filled to create a partial match, usable as matcher input.
     * 
     * @return the empty match.
     * 
     */
    public static PlayerDistinctRole.Match newEmptyMatch() {
      return new Mutable(null, null, null);
    }
    
    /**
     * Returns a mutable (partial) match.
     * Fields of the mutable match can be filled to create a partial match, usable as matcher input.
     * 
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return the new, mutable (partial) match object.
     * 
     */
    public static PlayerDistinctRole.Match newMutableMatch(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return new Mutable(pP1, pP2, pCommonRole);
    }
    
    /**
     * Returns a new (partial) match.
     * This can be used e.g. to call the matcher with a partial match.
     * <p>The returned match will be immutable. Use {@link #newEmptyMatch()} to obtain a mutable match object.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return the (partial) match object.
     * 
     */
    public static PlayerDistinctRole.Match newMatch(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return new Immutable(pP1, pP2, pCommonRole);
    }
    
    private static final class Mutable extends PlayerDistinctRole.Match {
      Mutable(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
        super(pP1, pP2, pCommonRole);
      }
      
      @Override
      public boolean isMutable() {
        return true;
      }
    }
    
    private static final class Immutable extends PlayerDistinctRole.Match {
      Immutable(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
        super(pP1, pP2, pCommonRole);
      }
      
      @Override
      public boolean isMutable() {
        return false;
      }
    }
  }
  
  /**
   * Generated pattern matcher API of the ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole pattern,
   * providing pattern-specific query methods.
   * 
   * <p>Use the pattern matcher on a given model via {@link #on(ViatraQueryEngine)},
   * e.g. in conjunction with {@link ViatraQueryEngine#on(QueryScope)}.
   * 
   * <p>Matches of the pattern will be represented as {@link Match}.
   * 
   * <p>Original source:
   * <code><pre>
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "Distance count", key = {o1})
   * //pattern countDistance(o1 : FTDistance){
   * //	FTDistance(o1);
   * //}
   * 
   * 
   * //3. Dynamic Classes
   * /
   * 
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "Trajectory count", key = {o1})
   * //pattern countTrajectory(o1 : FTTrajectory){
   * //	FTTrajectory(o1);
   * //}
   * //
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "State count", key = {o1})
   * //pattern countState(o1 : FTState){
   * //	FTState(o1);
   * //}
   * //
   * //
   * //private pattern helperFTDistanceObs(o1 : FTDistanceObs){
   * //	FTDistanceObs(o1);
   * //}
   * //
   * //private pattern helperFTZoneObs(o1 : FTZoneObs){
   * //	FTZoneObs(o1);
   * //}
   * //
   * //private pattern helperFTPickupObs(o1 : FTPickUpObs){
   * //	FTPickUpObs(o1);
   * //}
   * //
   * //private pattern helperFTHangingObs(o1 : FTHangingObs){
   * //	FTHangingObs(o1);
   * //}
   * //
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "Making Observations Abstract", key = {o1})
   * //pattern countObservation(o1 : FTObservation){
   * //	FTObservation(o1);
   * //	neg find helperFTDistanceObs(o1);
   * //	neg find helperFTZoneObs(o1);
   * //	neg find helperFTPickupObs(o1);
   * //	neg find helperFTHangingObs(o1);
   * //}
   * //
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "DistanceObs count", key = {o1})
   * //pattern countDistanceObs(o1 : FTDistanceObs){
   * //	FTDistanceObs(o1);
   * //}
   * //
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "ZoneObs count", key = {o1})
   * //pattern countZoneObs(o1 : FTZoneObs){
   * //	FTZoneObs(o1);
   * //}
   * //
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "PickUpObs count", key = {o1})
   * //pattern countPickUpObs(o1 : FTPickUpObs){
   * //	FTPickUpObs(o1);
   * //}
   * //
   * //{@literal @}Constraint(targetEditorId = "ca.mcgill.ecse.fairtracks.FairtracksDsl", severity = "error", message = "HangingObs count", key = {o1})
   * //pattern countHangingsObs(o1 : FTHangingObs){
   * //	FTHangingObs(o1);
   * //}
   * 
   * 
   * /
   * //StaticObject Constraints
   * /
   * 
   * /
   * //Player Constraints
   * /
   * 
   * //#1
   * //keys are for symetry. will not give 2 errors for this
   * {@literal @}Constraint(
   * 	targetEditorId = "ca.mcgill.ecse.FairtracksDsl", 
   * 	severity = "error", 
   * 	message = "Players have duplicate role", 
   * 	key = {p1, p2}
   * )
   * pattern PlayerDistinctRole(	
   * 	p1 : FTPlayer, 	p2 : FTPlayer, commonRole : FTRole
   * ) {
   * 	FTPlayer.role(p1, commonRole);
   * 	FTPlayer.role(p2, commonRole);
   * 	p1 != p2;
   * }
   * </pre></code>
   * 
   * @see Match
   * @see PlayerDistinctRole
   * 
   */
  public static class Matcher extends BaseMatcher<PlayerDistinctRole.Match> {
    /**
     * Initializes the pattern matcher within an existing VIATRA Query engine.
     * If the pattern matcher is already constructed in the engine, only a light-weight reference is returned.
     * 
     * @param engine the existing VIATRA Query engine in which this matcher will be created.
     * @throws ViatraQueryRuntimeException if an error occurs during pattern matcher creation
     * 
     */
    public static PlayerDistinctRole.Matcher on(final ViatraQueryEngine engine) {
      // check if matcher already exists
      Matcher matcher = engine.getExistingMatcher(querySpecification());
      if (matcher == null) {
          matcher = (Matcher)engine.getMatcher(querySpecification());
      }
      return matcher;
    }
    
    /**
     * @throws ViatraQueryRuntimeException if an error occurs during pattern matcher creation
     * @return an initialized matcher
     * @noreference This method is for internal matcher initialization by the framework, do not call it manually.
     * 
     */
    public static PlayerDistinctRole.Matcher create() {
      return new Matcher();
    }
    
    private final static int POSITION_P1 = 0;
    
    private final static int POSITION_P2 = 1;
    
    private final static int POSITION_COMMONROLE = 2;
    
    private final static Logger LOGGER = ViatraQueryLoggingUtil.getLogger(PlayerDistinctRole.Matcher.class);
    
    /**
     * Initializes the pattern matcher within an existing VIATRA Query engine.
     * If the pattern matcher is already constructed in the engine, only a light-weight reference is returned.
     * 
     * @param engine the existing VIATRA Query engine in which this matcher will be created.
     * @throws ViatraQueryRuntimeException if an error occurs during pattern matcher creation
     * 
     */
    private Matcher() {
      super(querySpecification());
    }
    
    /**
     * Returns the set of all matches of the pattern that conform to the given fixed values of some parameters.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return matches represented as a Match object.
     * 
     */
    public Collection<PlayerDistinctRole.Match> getAllMatches(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return rawStreamAllMatches(new Object[]{pP1, pP2, pCommonRole}).collect(Collectors.toSet());
    }
    
    /**
     * Returns a stream of all matches of the pattern that conform to the given fixed values of some parameters.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return a stream of matches represented as a Match object.
     * 
     */
    public Stream<PlayerDistinctRole.Match> streamAllMatches(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return rawStreamAllMatches(new Object[]{pP1, pP2, pCommonRole});
    }
    
    /**
     * Returns an arbitrarily chosen match of the pattern that conforms to the given fixed values of some parameters.
     * Neither determinism nor randomness of selection is guaranteed.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return a match represented as a Match object, or null if no match is found.
     * 
     */
    public Optional<PlayerDistinctRole.Match> getOneArbitraryMatch(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return rawGetOneArbitraryMatch(new Object[]{pP1, pP2, pCommonRole});
    }
    
    /**
     * Indicates whether the given combination of specified pattern parameters constitute a valid pattern match,
     * under any possible substitution of the unspecified parameters (if any).
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return true if the input is a valid (partial) match of the pattern.
     * 
     */
    public boolean hasMatch(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return rawHasMatch(new Object[]{pP1, pP2, pCommonRole});
    }
    
    /**
     * Returns the number of all matches of the pattern that conform to the given fixed values of some parameters.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return the number of pattern matches found.
     * 
     */
    public int countMatches(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return rawCountMatches(new Object[]{pP1, pP2, pCommonRole});
    }
    
    /**
     * Executes the given processor on an arbitrarily chosen match of the pattern that conforms to the given fixed values of some parameters.
     * Neither determinism nor randomness of selection is guaranteed.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @param processor the action that will process the selected match.
     * @return true if the pattern has at least one match with the given parameter values, false if the processor was not invoked
     * 
     */
    public boolean forOneArbitraryMatch(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole, final Consumer<? super PlayerDistinctRole.Match> processor) {
      return rawForOneArbitraryMatch(new Object[]{pP1, pP2, pCommonRole}, processor);
    }
    
    /**
     * Returns a new (partial) match.
     * This can be used e.g. to call the matcher with a partial match.
     * <p>The returned match will be immutable. Use {@link #newEmptyMatch()} to obtain a mutable match object.
     * @param pP1 the fixed value of pattern parameter p1, or null if not bound.
     * @param pP2 the fixed value of pattern parameter p2, or null if not bound.
     * @param pCommonRole the fixed value of pattern parameter commonRole, or null if not bound.
     * @return the (partial) match object.
     * 
     */
    public PlayerDistinctRole.Match newMatch(final FTPlayer pP1, final FTPlayer pP2, final FTRole pCommonRole) {
      return PlayerDistinctRole.Match.newMatch(pP1, pP2, pCommonRole);
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    protected Stream<FTPlayer> rawStreamAllValuesOfp1(final Object[] parameters) {
      return rawStreamAllValues(POSITION_P1, parameters).map(FTPlayer.class::cast);
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTPlayer> getAllValuesOfp1() {
      return rawStreamAllValuesOfp1(emptyArray()).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Stream<FTPlayer> streamAllValuesOfp1() {
      return rawStreamAllValuesOfp1(emptyArray());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     *      
     * @return the Stream of all values or empty set if there are no matches
     * 
     */
    public Stream<FTPlayer> streamAllValuesOfp1(final PlayerDistinctRole.Match partialMatch) {
      return rawStreamAllValuesOfp1(partialMatch.toArray());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     *      
     * @return the Stream of all values or empty set if there are no matches
     * 
     */
    public Stream<FTPlayer> streamAllValuesOfp1(final FTPlayer pP2, final FTRole pCommonRole) {
      return rawStreamAllValuesOfp1(new Object[]{null, pP2, pCommonRole});
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTPlayer> getAllValuesOfp1(final PlayerDistinctRole.Match partialMatch) {
      return rawStreamAllValuesOfp1(partialMatch.toArray()).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p1.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTPlayer> getAllValuesOfp1(final FTPlayer pP2, final FTRole pCommonRole) {
      return rawStreamAllValuesOfp1(new Object[]{null, pP2, pCommonRole}).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    protected Stream<FTPlayer> rawStreamAllValuesOfp2(final Object[] parameters) {
      return rawStreamAllValues(POSITION_P2, parameters).map(FTPlayer.class::cast);
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTPlayer> getAllValuesOfp2() {
      return rawStreamAllValuesOfp2(emptyArray()).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Stream<FTPlayer> streamAllValuesOfp2() {
      return rawStreamAllValuesOfp2(emptyArray());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     *      
     * @return the Stream of all values or empty set if there are no matches
     * 
     */
    public Stream<FTPlayer> streamAllValuesOfp2(final PlayerDistinctRole.Match partialMatch) {
      return rawStreamAllValuesOfp2(partialMatch.toArray());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     *      
     * @return the Stream of all values or empty set if there are no matches
     * 
     */
    public Stream<FTPlayer> streamAllValuesOfp2(final FTPlayer pP1, final FTRole pCommonRole) {
      return rawStreamAllValuesOfp2(new Object[]{pP1, null, pCommonRole});
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTPlayer> getAllValuesOfp2(final PlayerDistinctRole.Match partialMatch) {
      return rawStreamAllValuesOfp2(partialMatch.toArray()).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for p2.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTPlayer> getAllValuesOfp2(final FTPlayer pP1, final FTRole pCommonRole) {
      return rawStreamAllValuesOfp2(new Object[]{pP1, null, pCommonRole}).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    protected Stream<FTRole> rawStreamAllValuesOfcommonRole(final Object[] parameters) {
      return rawStreamAllValues(POSITION_COMMONROLE, parameters).map(FTRole.class::cast);
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTRole> getAllValuesOfcommonRole() {
      return rawStreamAllValuesOfcommonRole(emptyArray()).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Stream<FTRole> streamAllValuesOfcommonRole() {
      return rawStreamAllValuesOfcommonRole(emptyArray());
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     *      
     * @return the Stream of all values or empty set if there are no matches
     * 
     */
    public Stream<FTRole> streamAllValuesOfcommonRole(final PlayerDistinctRole.Match partialMatch) {
      return rawStreamAllValuesOfcommonRole(partialMatch.toArray());
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * </p>
     * <strong>NOTE</strong>: It is important not to modify the source model while the stream is being processed.
     * If the match set of the pattern changes during processing, the contents of the stream is <strong>undefined</strong>.
     * In such cases, either rely on {@link #getAllMatches()} or collect the results of the stream in end-user code.
     *      
     * @return the Stream of all values or empty set if there are no matches
     * 
     */
    public Stream<FTRole> streamAllValuesOfcommonRole(final FTPlayer pP1, final FTPlayer pP2) {
      return rawStreamAllValuesOfcommonRole(new Object[]{pP1, pP2, null});
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTRole> getAllValuesOfcommonRole(final PlayerDistinctRole.Match partialMatch) {
      return rawStreamAllValuesOfcommonRole(partialMatch.toArray()).collect(Collectors.toSet());
    }
    
    /**
     * Retrieve the set of values that occur in matches for commonRole.
     * @return the Set of all values or empty set if there are no matches
     * 
     */
    public Set<FTRole> getAllValuesOfcommonRole(final FTPlayer pP1, final FTPlayer pP2) {
      return rawStreamAllValuesOfcommonRole(new Object[]{pP1, pP2, null}).collect(Collectors.toSet());
    }
    
    @Override
    protected PlayerDistinctRole.Match tupleToMatch(final Tuple t) {
      try {
          return PlayerDistinctRole.Match.newMatch((FTPlayer) t.get(POSITION_P1), (FTPlayer) t.get(POSITION_P2), (FTRole) t.get(POSITION_COMMONROLE));
      } catch(ClassCastException e) {
          LOGGER.error("Element(s) in tuple not properly typed!",e);
          return null;
      }
    }
    
    @Override
    protected PlayerDistinctRole.Match arrayToMatch(final Object[] match) {
      try {
          return PlayerDistinctRole.Match.newMatch((FTPlayer) match[POSITION_P1], (FTPlayer) match[POSITION_P2], (FTRole) match[POSITION_COMMONROLE]);
      } catch(ClassCastException e) {
          LOGGER.error("Element(s) in array not properly typed!",e);
          return null;
      }
    }
    
    @Override
    protected PlayerDistinctRole.Match arrayToMatchMutable(final Object[] match) {
      try {
          return PlayerDistinctRole.Match.newMutableMatch((FTPlayer) match[POSITION_P1], (FTPlayer) match[POSITION_P2], (FTRole) match[POSITION_COMMONROLE]);
      } catch(ClassCastException e) {
          LOGGER.error("Element(s) in array not properly typed!",e);
          return null;
      }
    }
    
    /**
     * @return the singleton instance of the query specification of this pattern
     * @throws ViatraQueryRuntimeException if the pattern definition could not be loaded
     * 
     */
    public static IQuerySpecification<PlayerDistinctRole.Matcher> querySpecification() {
      return PlayerDistinctRole.instance();
    }
  }
  
  private PlayerDistinctRole() {
    super(GeneratedPQuery.INSTANCE);
  }
  
  /**
   * @return the singleton instance of the query specification
   * @throws ViatraQueryRuntimeException if the pattern definition could not be loaded
   * 
   */
  public static PlayerDistinctRole instance() {
    try{
        return LazyHolder.INSTANCE;
    } catch (ExceptionInInitializerError err) {
        throw processInitializerError(err);
    }
  }
  
  @Override
  protected PlayerDistinctRole.Matcher instantiate(final ViatraQueryEngine engine) {
    return PlayerDistinctRole.Matcher.on(engine);
  }
  
  @Override
  public PlayerDistinctRole.Matcher instantiate() {
    return PlayerDistinctRole.Matcher.create();
  }
  
  @Override
  public PlayerDistinctRole.Match newEmptyMatch() {
    return PlayerDistinctRole.Match.newEmptyMatch();
  }
  
  @Override
  public PlayerDistinctRole.Match newMatch(final Object... parameters) {
    return PlayerDistinctRole.Match.newMatch((ca.mcgill.ecse.fairtracks.fairtracksDsl.FTPlayer) parameters[0], (ca.mcgill.ecse.fairtracks.fairtracksDsl.FTPlayer) parameters[1], (ca.mcgill.ecse.fairtracks.fairtracksDsl.FTRole) parameters[2]);
  }
  
  /**
   * Inner class allowing the singleton instance of {@link JvmGenericType: ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole (visibility: PUBLIC, simpleName: PlayerDistinctRole, identifier: ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole, deprecated: <unset>) (abstract: false, static: false, final: true, packageName: ca.mcgill.ecse.fairtracks.queries) (interface: false, strictFloatingPoint: false, anonymous: false)} to be created 
   *     <b>not</b> at the class load time of the outer class, 
   *     but rather at the first call to {@link JvmGenericType: ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole (visibility: PUBLIC, simpleName: PlayerDistinctRole, identifier: ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole, deprecated: <unset>) (abstract: false, static: false, final: true, packageName: ca.mcgill.ecse.fairtracks.queries) (interface: false, strictFloatingPoint: false, anonymous: false)#instance()}.
   * 
   * <p> This workaround is required e.g. to support recursion.
   * 
   */
  private static class LazyHolder {
    private final static PlayerDistinctRole INSTANCE = new PlayerDistinctRole();
    
    /**
     * Statically initializes the query specification <b>after</b> the field {@link #INSTANCE} is assigned.
     * This initialization order is required to support indirect recursion.
     * 
     * <p> The static initializer is defined using a helper field to work around limitations of the code generator.
     * 
     */
    private final static Object STATIC_INITIALIZER = ensureInitialized();
    
    public static Object ensureInitialized() {
      INSTANCE.ensureInitializedInternal();
      return null;
    }
  }
  
  private static class GeneratedPQuery extends BaseGeneratedEMFPQuery {
    private final static PlayerDistinctRole.GeneratedPQuery INSTANCE = new GeneratedPQuery();
    
    private final PParameter parameter_p1 = new PParameter("p1", "ca.mcgill.ecse.fairtracks.fairtracksDsl.FTPlayer", new EClassTransitiveInstancesKey((EClass)getClassifierLiteralSafe("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer")), PParameterDirection.INOUT);
    
    private final PParameter parameter_p2 = new PParameter("p2", "ca.mcgill.ecse.fairtracks.fairtracksDsl.FTPlayer", new EClassTransitiveInstancesKey((EClass)getClassifierLiteralSafe("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer")), PParameterDirection.INOUT);
    
    private final PParameter parameter_commonRole = new PParameter("commonRole", "ca.mcgill.ecse.fairtracks.fairtracksDsl.FTRole", new EDataTypeInSlotsKey((EDataType)getClassifierLiteralSafe("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTRole")), PParameterDirection.INOUT);
    
    private final List<PParameter> parameters = Arrays.asList(parameter_p1, parameter_p2, parameter_commonRole);
    
    private GeneratedPQuery() {
      super(PVisibility.PUBLIC);
    }
    
    @Override
    public String getFullyQualifiedName() {
      return "ca.mcgill.ecse.fairtracks.queries.PlayerDistinctRole";
    }
    
    @Override
    public List<String> getParameterNames() {
      return Arrays.asList("p1","p2","commonRole");
    }
    
    @Override
    public List<PParameter> getParameters() {
      return parameters;
    }
    
    @Override
    public Set<PBody> doGetContainedBodies() {
      setEvaluationHints(new QueryEvaluationHint(null, QueryEvaluationHint.BackendRequirement.UNSPECIFIED));
      Set<PBody> bodies = new LinkedHashSet<>();
      {
          PBody body = new PBody(this);
          PVariable var_p1 = body.getOrCreateVariableByName("p1");
          PVariable var_p2 = body.getOrCreateVariableByName("p2");
          PVariable var_commonRole = body.getOrCreateVariableByName("commonRole");
          new TypeConstraint(body, Tuples.flatTupleOf(var_p1), new EClassTransitiveInstancesKey((EClass)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer")));
          new TypeConstraint(body, Tuples.flatTupleOf(var_p2), new EClassTransitiveInstancesKey((EClass)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer")));
          new TypeConstraint(body, Tuples.flatTupleOf(var_commonRole), new EDataTypeInSlotsKey((EDataType)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTRole")));
          body.setSymbolicParameters(Arrays.<ExportedParameter>asList(
             new ExportedParameter(body, var_p1, parameter_p1),
             new ExportedParameter(body, var_p2, parameter_p2),
             new ExportedParameter(body, var_commonRole, parameter_commonRole)
          ));
          // 	FTPlayer.role(p1, commonRole)
          new TypeConstraint(body, Tuples.flatTupleOf(var_p1), new EClassTransitiveInstancesKey((EClass)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer")));
          PVariable var__virtual_0_ = body.getOrCreateVariableByName(".virtual{0}");
          new TypeConstraint(body, Tuples.flatTupleOf(var_p1, var__virtual_0_), new EStructuralFeatureInstancesKey(getFeatureLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer", "role")));
          new TypeConstraint(body, Tuples.flatTupleOf(var__virtual_0_), new EDataTypeInSlotsKey((EDataType)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTRole")));
          new Equality(body, var__virtual_0_, var_commonRole);
          // 	FTPlayer.role(p2, commonRole)
          new TypeConstraint(body, Tuples.flatTupleOf(var_p2), new EClassTransitiveInstancesKey((EClass)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer")));
          PVariable var__virtual_1_ = body.getOrCreateVariableByName(".virtual{1}");
          new TypeConstraint(body, Tuples.flatTupleOf(var_p2, var__virtual_1_), new EStructuralFeatureInstancesKey(getFeatureLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTPlayer", "role")));
          new TypeConstraint(body, Tuples.flatTupleOf(var__virtual_1_), new EDataTypeInSlotsKey((EDataType)getClassifierLiteral("http://www.mcgill.ca/ecse/fairtracks/FairtracksDsl", "FTRole")));
          new Equality(body, var__virtual_1_, var_commonRole);
          // 	p1 != p2
          new Inequality(body, var_p1, var_p2);
          bodies.add(body);
      }
      {
          PAnnotation annotation = new PAnnotation("Constraint");
          annotation.addAttribute("targetEditorId", "ca.mcgill.ecse.FairtracksDsl");
          annotation.addAttribute("severity", "error");
          annotation.addAttribute("message", "Players have duplicate role");
          annotation.addAttribute("key", Arrays.asList(new Object[] {
                              new ParameterReference("p1"), 
                              new ParameterReference("p2")
                              }));
          addAnnotation(annotation);
      }
      return bodies;
    }
  }
}
